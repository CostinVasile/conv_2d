// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xconv_2d.h"

extern XConv_2d_Config XConv_2d_ConfigTable[];

XConv_2d_Config *XConv_2d_LookupConfig(u16 DeviceId) {
	XConv_2d_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCONV_2D_NUM_INSTANCES; Index++) {
		if (XConv_2d_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XConv_2d_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XConv_2d_Initialize(XConv_2d *InstancePtr, u16 DeviceId) {
	XConv_2d_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XConv_2d_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XConv_2d_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

